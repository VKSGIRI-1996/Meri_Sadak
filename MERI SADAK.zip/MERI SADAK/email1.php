<?php
    $name  = $_POST['firstname'];
    $address  = $_POST['address'];
    $gender  = $_POST['gender'];
    $contact  = $_POST['contact'];
    $email  = $_POST['email'];
    $state  = $_POST['state'];
    $complain  = $_POST['complain'];

    $conn = new mysqli('localhost','root','complain');
    if($conn->connect_error){
        die('Connection Failed   :     '$conn->connect_error);
    }else {
        $stmt = $conn->prepare("insert into registration(name, address, gender, contact, email, state, complain)values(?,?,?,?,?,?,?");
        $stmt->bind_param("sssisss",$name, $address, $gender, $contact, $email, $state, $complain);
        $stmt->execute();
        echo "Registration Successfully...";
        $stmt->close();
        $conn->close();
    }
?>