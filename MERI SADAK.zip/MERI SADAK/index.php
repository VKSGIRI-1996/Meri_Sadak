<!DOCTYPE html>
<html>
<head>
<style>
	body{
	    background-color:black;
		 }
    s{
        color:deepskyblue;
		font-family:Verdana;
		font-size:295%;
		border:1px solid green;
		padding:25px;
        margin:10;
		background-color:yellow;
    }
	h1{
		color:green;
		font-family:Verdana;
		font-size:400%;
		border:1px solid green;
		padding:80px;
        background-image:url("download.jpg");
      }
	h2{
		color:Red;
		font-family:Verdana;
		font-size:175%;
		border:1px light pink;
		padding:20px;
		background-color:yellow;
	  }
	 ul	
		{
		list-style-type:none;
		margin:0;
		padding:0;
		font-size:125%;
		overflow:hidden;
		background-color:#444444;
		}
	 li{
		float:left;
	   }
     li a{
		display:block;
		color:white;
		text-align:center;
		padding:15px;
		  }
	 li a:hover
		{
		background-color:#111111;
		}
	p{
		color:tomato;
		font-family:TIMES NEW ROMAN;
		Font-size:150%;
	
	 }
</style>
</head>
<body>
    <br>
    <s style="text-align:center;">   WELCOME TO "MERI SADAK" GOVT OF INDIA WEBSITE  </s> 
    <br>
    <pre><h1></h1></pre>
<ul>
	<li><u><a href="About1.php">About</a></li>
	<li><a href="Contact.php">Contact</a></li>
	<li><a href="Complain.php">Complain File</a></li>
	<li><a href="Service.php">Services Running</a></li>
</ul>
<p>MERI SADAK is a webpage in  which the customer can register the complain about the <u><a href="Complain.php">ROAD DAMAGE</a></u> in the society so that the Muncipal Corporation 
	know about this damage and take the corresponding action to reslove this damage.On this webpage the customer can also see that the Municipal 
	Corporation have taken an action about their complain by visiting  the <u><a href="Service.php">Services Running</a></u>. It also has an app named <u><a href="MERI SADAK.php">MERI SADAK</a> </u>. 
	“Meri Sadak” is an android application by which any Indian Citizen can give his/her feedback on the pace of PMGSY road work, quality of PMGSY road 
	work etc. (PMGSY stands for Pradhan Mantri Gram Sadak Yojana) to the related Departments in State Government or National Rural Roads Development 
	Agency (NRRDA). This app also allows the user to take multiple photographs of the road and submit them along with the feedback.
</p>
<img src="1.jpg" height="400px" width="450px";>
<img src="giphy.gif" height="400px" width="450px">
<img src="3.jpg" height="400px" width="450px";><br>
<p>
भारत सरकार ने 25 दिसंबर 2000 को प्रधानमंत्री ग्राम सड़क योजना की शुरुआत की थी। इस योजना का प्रमुख उद्देश्‍य ग्रामीण इलाकों में 500 या इससे अधिक आबादी वाले (पहाड़ी और रेगिस्‍तानी क्षेत्रों में 250 लोगों की आबादी वाले गांव) सड़क-संपर्क से वंचित गांवों को बारहमासी सड़कों
 से जोड़ना है। तत्कालीन प्रधानमंत्री अटल बिहारी वाजपेयी सरकार के वक्त से ही इसका नाम प्रधानमंत्री ग्राम सड़क योजना है। इस स्कीम का सबसे बड़ा फायदा गांवों को होगा, जहां छोटे किसान शहरों से सीधे जुड़ सकेंगे और अपनी फसल बेच पाएंगे। प्रधानमंत्री ग्राम सड़क योजना में सड़कों 
 को सही रखना यानि अगर किसी तरह की परेशानी से सड़क खराब होती है तो उसका भी ख्याल रखा जाएगा।
</p>
<img src="MODI.jpg"height="400px" width="450px";>
<img src="complain.jpg"heIght="400px" width="450px";>
<img src="9.jpg"heIght="400px" width="450px";>


<h2>Subscribe to <u>MERI SADAK</u> ----------Keep inform about the latest News and Updates</h2><br>
<a style="border:7px;background-color:tomato;padding:30px" href="about1.php">ABOUT</a>
<a style="border:7px;background-color:powderblue;padding:30px" href="contact.php">CONTACT</a>
<a style="border:7px;background-color:lightPINK;padding:30px" href="service.php">SERVICE</a>
<a Style="border:7px;background-color:#666666;padding:30px" href="Complain.php">Complain File</a>
<br><br>
<h2>All rights are preserved</h2>
</body>
</html>



