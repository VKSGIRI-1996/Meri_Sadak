<html>
<head>
<style>
	body{
		background-image:url("road1.jpg");
			background-repeat:no-repeat;
			background-size:cover;
		}
	marquee{
		font-size:300%;
		color:cyan;
		font-family:Aerial;
			}
	h1{
		color:red;
		font-family:Verdana;
		font-size:370%;
		border:1px solid green;
		padding:50px;
        text-align: center;
		background-image:url("download.jpg");
 	  }
	p{
		color:WHITE;
		font-family:verdana;
		font-size:200%;
	 }
	
	a{
		color:green;
		font-family:verdana;
		font-size:90%;
		border:1px solid pink;
		padding:10px;
		background-color:yellow;
		text-align:center;
		margin=0;

	 }
		
</style>
</head>
<body>
<pre><h1>  ABOUT      US</h1></pre>
<marquee direction="left">'सबका साथ, सबका विकास, सबका विश्वास' </marquee>

<img src="complain.jpg" height="400px" width="600px">
<img src="6.jpg" height="400px" width="780px"><p>“Meri Sadak” is an android application by which any Indian Citizen can give his/her 
feedback on the pace of PMGSY road work, quality of PMGSYroad work etc. (PMGSY stands for Pradhan Mantri Gram Sadak Yojana) to the related Departments
 in State Government or Nationational Rural Roads Development Agency (NRRDA). This app also allows the user to take multiple photographs of the road 
 and submit them along with the feedback.
 “Meri Sadak” is a mobile app to enable users to give their feedback regarding pace of works, quality of works etc. of PMGSY roads to the Nodal 
 Departments in the State Governments / National Rural Roads Development Agency (NRRDA). The user can take photographs at the site and submit along
 with feedback. After submission of feedback, the user can monitor the redressal of his / her feedback through this app. The respective State Quality 
 Coordinators (SQCs) of the Nodal Department implementing PMGSY will provide an interim response to the user. It is hoped that this application will 
 make the system of implementation of PMGSY more transparent and accountable to the benefit of all.
</p>
<img src="rgif2.gif" height="340px" width="1390px"><br><br>
<a href="index.php">HOME</a>
</body>
</html>