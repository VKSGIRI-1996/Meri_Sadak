<!DOCTYPE html>
<html>
<head>
<style>
p
	{
	background-image:url("download.jpg");
	border:1px solid pink;
	padding:80px;
	}
	
div
	{
	width:1350px;
	height:700px;
	padding:20px;
	border:1px solid black align center;
	background-color:LightGray;
	text-align:center;
	}
marquee
	{
	Font-size:200%;
	}
</style>
</head>
<body style="background-color:MediumSeaGreen">
<form action="complain1.php" method="post">
<p></p>
<marquee direction="right">Complaint File</marquee>
<div>
<pre style="font-size:18px">
Enter Name:
<input  type="text" name="name">
<br>
Enter Address:
<textarea name = "address"></textarea><br>
Gender:
<input type="radio" name="gender" value="male" checked>Male
<input type="radio" name="gender" value="female" checked>female
<input type="radio" name="gender" value="transgender" checked>transgender <br>
Enter Contact number:
<input type="number" name="cnumber">
<br>
Enter Email:
<input type="text" name="email">
<br>
Enter State:
<input type="text" name="state">
<br>
Enter Complain:
<input type="text" Complain="ps", name="complain" >
<br></pre>

<input type="submit"><br><br>
</form>
<a href="index.php">HOME</a>
</div>
</form>
</body>                 
</html>