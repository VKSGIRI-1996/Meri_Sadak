<html>
<head>
<style>
	body{
		background-image:url("road.jpg");
		background-repeat:no repeat;
		background-size:cover;
		}
	h1{
		color:red;
		font-family:Verdana;
		font-size:300%;
		border:1px solid green;
		padding:80px;
		background-image:url("download.jpg");
 	  }
	 h2{
		color:red;
		font-family:Verdana;
		font-size:250%;
		border:1px solid green;
		padding:100px;
		background-color:black;
		Text-align:center;
		}
	 marquee{
	 color:cyan;
	 font-size:300%;
	 font-family:Aerial;
			}
	 h3{
		color:Green;
		font-family:Verdana;
		font-size:300%;
		border:1px solid green;
		padding:10px;
		background-color:darkblue;
		Text-align:center;

	   }
	 #P01{
		color:orange;
	font-family:verdana;
	font-size:300%;
	border:1px sol0d pink;
	padding:10px;
	background-color:MediumSeablue;
	text-align:center;		
	      }
	p{
		color:WHITE;
		font-family:verdana;
		font-size:200%;
	 }
	a{
		color:red;
		font-family:verdana;
		font-size:90%;
		border:0px solid pink;
		padding:none;
		background-color:yellow;
		text-align:centre;
		background-align:centre;
	 }
	{
		color:green;
		font-family:verdana;
		font-size:90%;
		border:0px solid pink;
		padding:none;
		background-color:yellow;
		text-align:centre;
		background-align:centre;
	 }
</style>
</head>
<body >
<h1></h1>
<h3>SERVICES RUNNING</h3>
<marquee direction="left">You Have 5 Attempts To LOGIN! </marquee>
<h2><a href="adlogin.php">Administration
   LOGIN</h2></a>
   <h2><a href="stafflogin.php">Staff LOGIN</h2></a>
<h2 id="P01"><a class="P01" href="index.php">HOME</h2></a>
<p id="P01">GOOD LUCK FOR ALL THE SERVICES </p>
<p>All Rights Are Preserved</p>
</body>
</html>