<!DOCTYPE html>
<html>
<head>
<style>
p
	{
	background-image:url("download.jpg");
	border:1px solid pink;
	padding:80px;
	
	}
div
	{	
	width:1480px;
	height:400px;
	padding:20px;
	border:1px solid black align center;
	background-color:LightGray;
	text-align:center;
	
	font-size:28px;
	}

</style>
</head>
<body style="background-color:MediumseaGreen;">
<form action="adlogin1.php" method="post">
<p></p>
<div>
<form>
UserName:
<input type="text" name="name" required><br><br>
Password:
<input type="password" name="password" required><br><br>
<input type="Submit" style="height:45px; width:70px; font-size:20px" onclick="alert('Submitted Your Details')" value="Login"><br><br>
<a href="Newadmin.php" style="text-align:right ">New administrator</a><br><br>
<a href="index.php">HOME</a>
</form>
</div>


</body>
</html>