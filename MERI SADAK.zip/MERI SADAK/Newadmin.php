<!DOCTYPE html>
<html>
<head>
<style>
p
	{
	background-image:url("download.jpg");
	border:1px solid pink;
	padding:80px;
	}
	
div
	{
	width:1350px;
	height:880px;
	padding:20px;
	border:1px solid black align center;
	background-color:LightGray;
	text-align:center;
	font-size:18px;
	}
marquee
	{
	Font-size:200%;
	}
</style>
</head>
<body style="background-color:MediumSeaGreen">
<form action="newadmin1.php" method="post">
<p></p>
<marquee direction="right">WElCOME!</marquee>
<marquee direction="left">'सबका साथ, सबका विकास, सबका विश्वास'</marquee>
<div>
<form>
<pre > Enter Name:
<input  type="text" name="name" >
<br>
Enter Address:
<textarea name = "address"></textarea><br>
Gender:
<input type="radio" name="gender" value="male" checked>Male
<input type="radio" name="gender" value="female" checked>female
<input type="radio" name="gender" value="transgender" checked>transgender <br>
Enter Contact number:
<input type="number" name="cnumber">
<br>
Enter Email:
<input type="text" name="email">
<br>
Enter State:
<input type="text" name="state">
<br>
Enter UserName:
<input type="text" name="username" >
<br>
Enter Password:
<input type="password" name="password">
<br>
Confirm Password:
<input type="password" name="confirmpassword">
<br></pre>

<input type="submit" onclick="alert('Thank You!')" 

value="Submit"><br><br>
</form>
<a href="index.php">HOME</a>
</div>
</html>