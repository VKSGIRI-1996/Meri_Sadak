<html>
<body>
<?php
 
// Create connection
$conn = new mysqli('localhost','root','');
 
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "\n DB Connected successfully -->";
 
// this will select the Database sample_db
mysqli_select_db($conn,"merisadak");
 
echo "\n DB is seleted as Test  successfully-->";
 
// create INSERT query
 
 
$sql="INSERT INTO complain (name,address,gender,cnumber,email,state,complain) VALUES ('$_POST[name]','$_POST[address]','$_POST[gender]','$_POST[cnumber]','$_POST[email]','$_POST[state]','$_POST[complain]')";
 
if ($conn->query($sql) === TRUE) {
    echo "\n New record created successfully.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
 
mysqli_close($conn);
?>
</body>
</html>
